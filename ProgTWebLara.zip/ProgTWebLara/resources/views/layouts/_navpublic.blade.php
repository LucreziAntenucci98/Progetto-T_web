<img src="LogoINTERNO.jpeg" height="80px" class="header__logo">
<ul class="header_menu">
    <li class="header_menu_voce"><a href="{{ route('home') }}" title="Home">Home</a></li>
    <li class="header_menu_voce"><a href="{{ route('catalog1') }}" title="Catalogo">Catalogo</a>
      <ul class="catalogo">
            @foreach ($topCategories as $category)
                <li class="header_menu_voce_catalogo"><a href="{{ route('catalog2', [$category->catId]) }}">{{ $category->name }}</a></li>
                @endforeach
        </ul></li>
    <li class="header_menu_voce"><a href="{{ route('who') }}" title="Il nostro profilo aziendale">Chi siamo</a></li>
    <li class="header_menu_voce"><a href="{{ route('where') }}" title="Contattaci">Contatti</a></li>
    @can('isAdmin')
        <li><a href="{{ route('admin') }}" class="highlight" title="Home Admin">Admin</a></li>
    @endcan
    @can('isUser')
        <li><a href="{{ route('user') }}" class="highlight" title="Home User">User</a></li>
    @endcan
    @auth
        <li><a href="" title="Esci dal sito" class="highlight" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a></li>
        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            {{ csrf_field() }}
        </form>
    @endauth    
    @guest
        <li><a href="{{ route('login') }}" class="highlight" title="Accedi all'area riservata del sito">Accedi</a></li>  
    @endguest
</ul>