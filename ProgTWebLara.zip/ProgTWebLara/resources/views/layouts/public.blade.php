<!DOCTYPE html>
<html lang="{{str_replace('_','-',app()->getLocale())}}">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="{{asset('css/style.css')}}">     
        <title>ZABAuto&Moto | @yield('title','Home')</title>
    </head>
    <body>
        
        <header class="header">
        @include('layouts/_navpublic')
        </header>
            

            <!-- end #menu -->
            <div id="page">
                <div id="page-bgtop">
                    <div id="page-bgbtm">
                        @yield('content')
                        <div style="clear: both;">&nbsp;</div>
                    </div>
                </div>
            </div>

            <!-- end #content -->
        <footer class="footer">
                <p>Copyright  -  2020 ZABA</p>
        </footer>
    </body>
</html>